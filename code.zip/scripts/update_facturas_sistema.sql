-- Script para actualizar el sistema de facturación con IVA, Timbrado, RUC, etc.
-- Base de datos: samu

-- --------------------------------------------------------
-- Agregar campos adicionales a facturas_venta
-- --------------------------------------------------------

ALTER TABLE `facturas_venta` 
ADD COLUMN IF NOT EXISTS `timbrado` varchar(20) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `condiciones_venta` varchar(100) DEFAULT 'CONTADO',
ADD COLUMN IF NOT EXISTS `iva_porcentaje` decimal(5,2) DEFAULT 21.00,
ADD COLUMN IF NOT EXISTS `iva_monto` decimal(10,2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS `total_letras` varchar(500) DEFAULT NULL;

-- --------------------------------------------------------
-- Tabla de Configuración del Sistema
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `configuracion_sistema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_empresa` varchar(200) NOT NULL DEFAULT 'KinBech.Com',
  `ruc_empresa` varchar(20) NOT NULL,
  `direccion_empresa` varchar(300) NOT NULL,
  `telefono_empresa` varchar(50) NOT NULL,
  `email_empresa` varchar(100) DEFAULT NULL,
  `timbrado_actual` varchar(20) NOT NULL,
  `fecha_inicio_timbrado` date NOT NULL,
  `fecha_fin_timbrado` date NOT NULL,
  `numero_factura_inicio` int(11) NOT NULL DEFAULT 1,
  `numero_factura_actual` int(11) NOT NULL DEFAULT 1,
  `iva_porcentaje` decimal(5,2) NOT NULL DEFAULT 21.00,
  `logo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Insertar configuración inicial
-- --------------------------------------------------------

INSERT INTO `configuracion_sistema` 
(`nombre_empresa`, `ruc_empresa`, `direccion_empresa`, `telefono_empresa`, `email_empresa`, 
 `timbrado_actual`, `fecha_inicio_timbrado`, `fecha_fin_timbrado`, `numero_factura_inicio`, 
 `numero_factura_actual`, `iva_porcentaje`) 
VALUES
('KinBech.Com', '80012345-6', 'Av. Principal 123, Ciudad', '(021) 123-4567', 'info@kinbech.com',
 '12345678', '2025-01-01', '2025-12-31', 1, 1, 21.00)
ON DUPLICATE KEY UPDATE id=id;

COMMIT;
