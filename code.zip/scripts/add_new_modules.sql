-- Script para agregar módulos de Proveedores, Compras, Caja y Facturación
-- Base de datos: samu
-- Fecha: 2025

-- --------------------------------------------------------
-- Tabla de Proveedores (Suppliers)
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `proveedores` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `ruc` varchar(20) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contacto` varchar(100) NOT NULL,
  `estado` enum('activo','inactivo') NOT NULL DEFAULT 'activo',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ruc` (`ruc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Tabla de Compras (Purchases)
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `compras` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(100) NOT NULL,
  `admin_id` int(100) NOT NULL,
  `numero_factura` varchar(50) NOT NULL,
  `fecha_compra` date NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `estado` enum('pendiente','recibido','cancelado') NOT NULL DEFAULT 'pendiente',
  `observaciones` text DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `proveedor_id` (`proveedor_id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Tabla de Detalle de Compras (Purchase Details)
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `detalle_compras` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `compra_id` int(100) NOT NULL,
  `producto_id` int(100) NOT NULL,
  `cantidad` int(10) NOT NULL,
  `precio_compra` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `compra_id` (`compra_id`),
  KEY `producto_id` (`producto_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Tabla de Caja (Cash Register)
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `caja` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `admin_id` int(100) NOT NULL,
  `fecha_apertura` datetime NOT NULL,
  `fecha_cierre` datetime DEFAULT NULL,
  `monto_inicial` decimal(10,2) NOT NULL,
  `monto_final` decimal(10,2) DEFAULT NULL,
  `total_ventas` decimal(10,2) DEFAULT 0.00,
  `total_efectivo` decimal(10,2) DEFAULT 0.00,
  `total_tarjeta` decimal(10,2) DEFAULT 0.00,
  `diferencia` decimal(10,2) DEFAULT 0.00,
  `estado` enum('abierta','cerrada') NOT NULL DEFAULT 'abierta',
  `observaciones` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Tabla de Movimientos de Caja (Cash Movements)
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `movimientos_caja` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `caja_id` int(100) NOT NULL,
  `tipo` enum('ingreso','egreso') NOT NULL,
  `concepto` varchar(200) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `referencia` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `caja_id` (`caja_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Tabla de Facturas de Venta (Sales Invoices)
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `facturas_venta` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `order_id` int(100) NOT NULL,
  `caja_id` int(100) DEFAULT NULL,
  `numero_factura` varchar(50) NOT NULL,
  `fecha_emision` datetime NOT NULL DEFAULT current_timestamp(),
  `cliente_nombre` varchar(100) NOT NULL,
  `cliente_ruc` varchar(20) DEFAULT NULL,
  `cliente_direccion` varchar(200) DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `impuesto` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL,
  `metodo_pago` varchar(50) NOT NULL,
  `estado` enum('emitida','anulada') NOT NULL DEFAULT 'emitida',
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_factura` (`numero_factura`),
  KEY `order_id` (`order_id`),
  KEY `caja_id` (`caja_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Agregar campos adicionales a la tabla products
-- --------------------------------------------------------

ALTER TABLE `products` 
ADD COLUMN IF NOT EXISTS `stock` int(10) NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS `stock_minimo` int(10) NOT NULL DEFAULT 5,
ADD COLUMN IF NOT EXISTS `categoria` varchar(50) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `codigo` varchar(50) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `costo` decimal(10,2) DEFAULT 0.00;

-- --------------------------------------------------------
-- Agregar índice único al código de producto
-- --------------------------------------------------------

ALTER TABLE `products` 
ADD UNIQUE KEY IF NOT EXISTS `codigo` (`codigo`);

-- --------------------------------------------------------
-- Agregar relación entre orders y caja
-- --------------------------------------------------------

ALTER TABLE `orders` 
ADD COLUMN IF NOT EXISTS `caja_id` int(100) DEFAULT NULL,
ADD KEY IF NOT EXISTS `caja_id` (`caja_id`);

-- --------------------------------------------------------
-- Insertar datos de ejemplo para proveedores
-- --------------------------------------------------------

INSERT INTO `proveedores` (`nombre`, `ruc`, `direccion`, `telefono`, `email`, `contacto`, `estado`) VALUES
('Proveedor Ejemplo 1', '20123456789', 'Av. Principal 123', '987654321', 'proveedor1@example.com', 'Juan Pérez', 'activo'),
('Proveedor Ejemplo 2', '20987654321', 'Calle Secundaria 456', '912345678', 'proveedor2@example.com', 'María García', 'activo');

COMMIT;
