# Sistema de Facturación Completo

## Nuevas Funcionalidades Implementadas

### 1. IVA 21%
- Todas las facturas ahora calculan automáticamente el IVA del 21%
- El subtotal y el IVA se muestran por separado
- El porcentaje de IVA es configurable desde el panel de administración

### 2. Timbrado
- Cada factura incluye el número de timbrado
- El timbrado se configura en "Configuración del Sistema"
- Incluye fechas de inicio y fin de validez del timbrado

### 3. Condiciones de Venta
- Por defecto: CONTADO
- Se muestra en la factura impresa

### 4. RUC de la Empresa
- Configurado en "Configuración del Sistema"
- Se muestra en todas las facturas impresas

### 5. Teléfono del Local
- Configurado en "Configuración del Sistema"
- Se muestra en el encabezado de las facturas

### 6. Total en Letras y Números
- El total se muestra en números: $1,234.56
- El total se muestra en letras: MIL DOSCIENTOS TREINTA Y CUATRO CON 56/100 GUARANÍES
- Conversión automática usando la función numeroALetras()

### 7. Facturas Anuladas
- Nueva página: admin/facturas_anuladas.php
- Lista todas las facturas con estado "anulada"
- Marca visual en rojo para identificarlas fácilmente
- Al imprimir una factura anulada, aparece una marca de agua "ANULADA"

## Archivos SQL a Ejecutar

### 1. scripts/add_new_modules.sql
Crea las tablas base para:
- Proveedores
- Compras
- Caja
- Facturas de Venta

### 2. scripts/update_facturas_sistema.sql
Actualiza el sistema de facturación con:
- Campos adicionales en facturas_venta (timbrado, condiciones_venta, iva_porcentaje, etc.)
- Tabla configuracion_sistema con datos de la empresa
- Configuración inicial del sistema

## Configuración Inicial

1. **Ejecutar los scripts SQL en orden:**
   \`\`\`sql
   -- Primero
   source scripts/add_new_modules.sql;
   
   -- Segundo
   source scripts/update_facturas_sistema.sql;
   \`\`\`

2. **Configurar el Sistema:**
   - Ir a: Admin → Configuración
   - Completar los datos de la empresa:
     - Nombre de la empresa
     - RUC
     - Dirección
     - Teléfono
     - Email
   - Configurar facturación:
     - Número de timbrado
     - Fechas de validez del timbrado
     - Porcentaje de IVA (21% por defecto)

3. **Verificar Funcionamiento:**
   - Realizar una compra de prueba
   - Verificar que se genere la factura correctamente
   - Imprimir la factura y verificar todos los datos

## Nuevas Páginas del Sistema

- **admin/configuracion_sistema.php** - Configuración general del sistema
- **admin/facturas_anuladas.php** - Listado de facturas anuladas
- **components/numero_a_letras.php** - Función para convertir números a letras

## Flujo de Facturación

1. Cliente realiza compra en checkout.php
2. Se genera automáticamente:
   - Orden de compra
   - Factura con número correlativo
   - Registro en caja (si está abierta)
   - Movimiento de caja
3. La factura incluye:
   - Datos de la empresa (RUC, teléfono, dirección)
   - Timbrado y validez
   - Datos del cliente (nombre, RUC/CI opcional)
   - Detalle de productos
   - Subtotal, IVA 21%, Total
   - Total en letras
   - Condiciones de venta

## Características de la Factura Impresa

- Formato profesional tipo ticket fiscal
- Encabezado con datos de la empresa
- Número de factura y timbrado destacados
- Tabla de productos
- Cálculos claros (Subtotal + IVA = Total)
- Total en letras para mayor seguridad
- Información del timbrado al pie
- Marca de agua "ANULADA" si corresponde
