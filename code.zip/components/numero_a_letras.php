<?php
// Función para convertir números a letras en español (Paraguay)
function numeroALetras($numero) {
    $numero = number_format($numero, 2, '.', '');
    list($entero, $decimal) = explode('.', $numero);
    
    $entero = intval($entero);
    $decimal = intval($decimal);
    
    $letras = convertirEntero($entero);
    
    if($decimal > 0) {
        return strtoupper($letras . ' CON ' . $decimal . '/100 GUARANÍES');
    } else {
        return strtoupper($letras . ' GUARANÍES');
    }
}

function convertirEntero($numero) {
    $unidades = ['', 'UNO', 'DOS', 'TRES', 'CUATRO', 'CINCO', 'SEIS', 'SIETE', 'OCHO', 'NUEVE'];
    $decenas = ['', 'DIEZ', 'VEINTE', 'TREINTA', 'CUARENTA', 'CINCUENTA', 'SESENTA', 'SETENTA', 'OCHENTA', 'NOVENTA'];
    $especiales = ['DIEZ', 'ONCE', 'DOCE', 'TRECE', 'CATORCE', 'QUINCE', 'DIECISÉIS', 'DIECISIETE', 'DIECIOCHO', 'DIECINUEVE'];
    $centenas = ['', 'CIENTO', 'DOSCIENTOS', 'TRESCIENTOS', 'CUATROCIENTOS', 'QUINIENTOS', 'SEISCIENTOS', 'SETECIENTOS', 'OCHOCIENTOS', 'NOVECIENTOS'];
    
    if($numero == 0) return 'CERO';
    if($numero == 100) return 'CIEN';
    
    $letras = '';
    
    // Millones
    if($numero >= 1000000) {
        $millones = floor($numero / 1000000);
        if($millones == 1) {
            $letras .= 'UN MILLÓN ';
        } else {
            $letras .= convertirGrupo($millones) . ' MILLONES ';
        }
        $numero %= 1000000;
    }
    
    // Miles
    if($numero >= 1000) {
        $miles = floor($numero / 1000);
        if($miles == 1) {
            $letras .= 'MIL ';
        } else {
            $letras .= convertirGrupo($miles) . ' MIL ';
        }
        $numero %= 1000;
    }
    
    // Centenas, decenas y unidades
    if($numero > 0) {
        $letras .= convertirGrupo($numero);
    }
    
    return trim($letras);
}

function convertirGrupo($numero) {
    $unidades = ['', 'UNO', 'DOS', 'TRES', 'CUATRO', 'CINCO', 'SEIS', 'SIETE', 'OCHO', 'NUEVE'];
    $decenas = ['', 'DIEZ', 'VEINTE', 'TREINTA', 'CUARENTA', 'CINCUENTA', 'SESENTA', 'SETENTA', 'OCHENTA', 'NOVENTA'];
    $especiales = ['DIEZ', 'ONCE', 'DOCE', 'TRECE', 'CATORCE', 'QUINCE', 'DIECISÉIS', 'DIECISIETE', 'DIECIOCHO', 'DIECINUEVE'];
    $centenas = ['', 'CIENTO', 'DOSCIENTOS', 'TRESCIENTOS', 'CUATROCIENTOS', 'QUINIENTOS', 'SEISCIENTOS', 'SETECIENTOS', 'OCHOCIENTOS', 'NOVECIENTOS'];
    
    $letras = '';
    
    // Centenas
    if($numero >= 100) {
        $c = floor($numero / 100);
        if($numero == 100) {
            $letras .= 'CIEN';
            return $letras;
        } else {
            $letras .= $centenas[$c] . ' ';
        }
        $numero %= 100;
    }
    
    // Decenas y unidades
    if($numero >= 10 && $numero < 20) {
        $letras .= $especiales[$numero - 10];
    } elseif($numero >= 20) {
        $d = floor($numero / 10);
        $u = $numero % 10;
        if($u == 0) {
            $letras .= $decenas[$d];
        } else {
            $letras .= $decenas[$d] . ' Y ' . $unidades[$u];
        }
    } elseif($numero > 0) {
        $letras .= $unidades[$numero];
    }
    
    return trim($letras);
}
?>
