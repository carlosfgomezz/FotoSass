<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Acerca de</title>

   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
   
   <!-- enlace CDN de font awesome -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- enlace al archivo CSS personalizado -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="about">

   <div class="row">

      <div class="image">
         <img src="images/23.png" alt="">
      </div>

      <div class="content">
         <h3>Mensaje del Desarrollador:</h3>
         <p>¡Hola! Soy Harsh Chaudhary. Estudiante de Ingeniería de Software en NCIT College [Promoción: 2023]. Me encanta diseñar sitios web y explorar cosas nuevas. Aprender cosas nuevas es mi pasatiempo.</p>

         <p>Me gustaría agradecer a <a href="https://www.facebook.com/er.ashokbasnet" target="_blank">Er. Ashok Basnet</a> por guiarme durante el proceso y permitirme desarrollar proyectos como este.</p>
         <a href="contact.php" class="btn">Contáctanos</a>
      </div>

   </div>

</section>

<section class="reviews">
   
   <h1 class="heading">Opiniones de Clientes</h1>

   <div class="swiper reviews-slider">

   <div class="swiper-wrapper">

      <div class="swiper-slide slide">
         <img src="images/pic-5.jpg" alt="">
         <p>He estado usando sus servicios durante bastante tiempo y nunca he tenido problemas con la calidad de sus productos. Los productos electrónicos también funcionan muy bien. El único problema es que suelen entregar cuando estoy un poco ocupado, aunque he establecido un horario de entrega preferido. Todo lo demás ha sido bueno.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3> <a href="https://www.facebook.com/profile.php?id=100083292714419" target="_blank">Denisha Adhikari</a></h3>
      </div>

      <div class="swiper-slide slide">
         <img src="images/pic-1.jpg" alt="">
         <p>Es el primer servicio en línea en Nepal en el que podemos confiar completamente. Siempre grabo un video al desempacar y me quejo al instante si hay algo mal. A veces ni siquiera necesito devolver el artículo y procesan el reembolso. KinBech multa severamente a los vendedores que envían productos incorrectos, por eso su plataforma mejora día a día.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3><a href="https://www.facebook.com/profile.php?id=100075602340579" target="_blank">Rushab Risal</a></h3>
      </div>

      <div class="swiper-slide slide">
         <img src="images/pic-3.jpg" alt="">
         <p>KinBech es excelente si eliges buenos vendedores. Hay una gran variedad de artículos disponibles. Los clientes pueden devolver y recibir un reembolso completo dentro de 7 días fácilmente. KinBech está impulsando el comercio electrónico en Katmandú. Ofrece una gran oportunidad para vender artículos en línea con facilidad.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3><a href="https://www.facebook.com/kaushalsah135790" target="_blank">Kaushal Shah</a></h3>
      </div>

      <div class="swiper-slide slide">
         <img src="images/pic-7.jpg" alt="">
         <p>Usando KinBech para compras en línea desde hace casi 3 años. Experiencia sobresaliente con ellos. Los vales para juegos y el punto de recogida como entrega sin gastos de envío son servicios que permiten un gran ahorro.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3><a href="https://www.facebook.com/fuccheekta.moh.1" target="_blank">Subash Ray</a></h3>
      </div>

      <div class="swiper-slide slide">
         <img src="images/pic-2.jpg" alt="">
         <p>He estado usando sus servicios durante los últimos 2 años y los he encontrado extremadamente confiables. Su política de devolución es lo que te da una capa extra de confianza y tranquilidad. En caso de que el producto no cumpla con tus expectativas o si tiene algún defecto, puedes devolverlo dentro de los siete días posteriores a la fecha de entrega.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3><a href="https://www.facebook.com/ranjitchaudhary159" target="_blank">Ranjit Chaudhary</a></h3>
      </div>

      <div class="swiper-slide slide">
         <img src="images/pic-6.jpg" alt="">
         <p>¡KinBech es genial! He pedido cientos de productos y nunca he sufrido ninguna estafa. Entregan los productos a tiempo sin retrasos. El empaquetado de los productos es resistente y las tarifas de envío son muy bajas. Una web increíble, seguiré comprando en KinBech.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3><a href="https://www.facebook.com/pra.x.nil"  target="_blank">Pranil Poudel</a></h3>
      </div>

   </div>

   <div class="swiper-pagination"></div>

   </div>

</section>









<?php include 'components/footer.php'; ?>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

<script src="js/script.js"></script>

<script>

var swiper = new Swiper(".reviews-slider", {
   loop:true,
   spaceBetween: 20,
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
   },
   breakpoints: {
      0: {
        slidesPerView:1,
      },
      768: {
        slidesPerView: 2,
      },
      991: {
        slidesPerView: 3,
      },
   },
});

</script>

</body>
</html>
