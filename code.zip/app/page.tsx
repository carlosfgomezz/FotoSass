"use client"

import  from "../js/script"

export default function SyntheticV0PageForDeployment() {
  return < />
}