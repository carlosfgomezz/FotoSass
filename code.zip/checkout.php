<?php

include 'components/connect.php';
include 'components/numero_a_letras.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:user_login.php');
};

if(isset($_POST['order'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $method = $_POST['method'];
   $method = filter_var($method, FILTER_SANITIZE_STRING);
   $address = 'flat no. '. $_POST['flat'] .', '. $_POST['street'] .', '. $_POST['city'] .', '. $_POST['state'] .', '. $_POST['country'] .' - '. $_POST['pin_code'];
   $address = filter_var($address, FILTER_SANITIZE_STRING);
   $total_products = $_POST['total_products'];
   $total_price = $_POST['total_price'];
   $cliente_ruc = $_POST['ruc'];
   $cliente_ruc = filter_var($cliente_ruc, FILTER_SANITIZE_STRING);

   $check_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
   $check_cart->execute([$user_id]);

   if($check_cart->rowCount() > 0){

      $select_caja = $conn->prepare("SELECT id FROM `caja` WHERE estado = 'abierta' ORDER BY fecha_apertura DESC LIMIT 1");
      $select_caja->execute();
      $caja = $select_caja->fetch(PDO::FETCH_ASSOC);
      $caja_id = $caja ? $caja['id'] : null;

      $insert_order = $conn->prepare("INSERT INTO `orders`(user_id, name, number, email, method, address, total_products, total_price, caja_id) VALUES(?,?,?,?,?,?,?,?,?)");
      $insert_order->execute([$user_id, $name, $number, $email, $method, $address, $total_products, $total_price, $caja_id]);
      
      $order_id = $conn->lastInsertId();

      $select_config = $conn->prepare("SELECT * FROM `configuracion_sistema` WHERE id = 1");
      $select_config->execute();
      $config = $select_config->fetch(PDO::FETCH_ASSOC);

      $numero_factura_actual = $config['numero_factura_actual'];
      $numero_factura = str_pad($numero_factura_actual, 7, '0', STR_PAD_LEFT) . '-' . date('Ymd');
      
      $iva_porcentaje = $config['iva_porcentaje'];
      $subtotal = $total_price / (1 + ($iva_porcentaje / 100));
      $iva_monto = $total_price - $subtotal;
      
      $total_letras = numeroALetras($total_price);
      
      $insert_factura = $conn->prepare("INSERT INTO `facturas_venta`(order_id, caja_id, numero_factura, cliente_nombre, cliente_ruc, cliente_direccion, subtotal, iva_porcentaje, iva_monto, total, metodo_pago, timbrado, condiciones_venta, total_letras) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
      $insert_factura->execute([$order_id, $caja_id, $numero_factura, $name, $cliente_ruc, $address, $subtotal, $iva_porcentaje, $iva_monto, $total_price, $method, $config['timbrado_actual'], 'CONTADO', $total_letras]);

      $update_config = $conn->prepare("UPDATE `configuracion_sistema` SET numero_factura_actual = numero_factura_actual + 1 WHERE id = 1");
      $update_config->execute();

      if($caja_id){
         $concepto = 'Venta - Factura ' . $numero_factura;
         $insert_movimiento = $conn->prepare("INSERT INTO `movimientos_caja`(caja_id, tipo, concepto, monto, referencia) VALUES(?,?,?,?,?)");
         $insert_movimiento->execute([$caja_id, 'ingreso', $concepto, $total_price, $numero_factura]);
         
         // Update cash register totals
         if($method == 'cash on delivery'){
            $update_caja = $conn->prepare("UPDATE `caja` SET total_ventas = total_ventas + ?, total_efectivo = total_efectivo + ? WHERE id = ?");
            $update_caja->execute([$total_price, $total_price, $caja_id]);
         } else {
            $update_caja = $conn->prepare("UPDATE `caja` SET total_ventas = total_ventas + ?, total_tarjeta = total_tarjeta + ? WHERE id = ?");
            $update_caja->execute([$total_price, $total_price, $caja_id]);
         }
      }

      $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
      $delete_cart->execute([$user_id]);

      $message[] = '¡Pedido realizado con éxito! Factura N° ' . $numero_factura;
   }else{
      $message[] = 'Tu carrito está vacío';
   }

}

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Finalizar Compra</title>
   
   <!-- enlace CDN de font awesome -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- enlace al archivo CSS personalizado -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="checkout-orders">

   <form action="" method="POST">

   <h3>Tus Pedidos</h3>

      <div class="display-orders">
      <?php
         $grand_total = 0;
         $cart_items[] = '';
         $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
         $select_cart->execute([$user_id]);
         if($select_cart->rowCount() > 0){
            while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
               $cart_items[] = $fetch_cart['name'].' ('.$fetch_cart['price'].' x '. $fetch_cart['quantity'].') - ';
               $total_products = implode($cart_items);
               $grand_total += ($fetch_cart['price'] * $fetch_cart['quantity']);
      ?>
         <p> <?= $fetch_cart['name']; ?> <span>($<?= $fetch_cart['price'].' x '. $fetch_cart['quantity']; ?>)</span> </p>
      <?php
            }
         }else{
            echo '<p class="empty">¡Tu carrito está vacío!</p>';
         }
      ?>
         <input type="hidden" name="total_products" value="<?= $total_products; ?>">
         <input type="hidden" name="total_price" value="<?= $grand_total; ?>" value="">
         <div class="grand-total">Total: <span>$<?= $grand_total; ?></span></div>
      </div>

      <h3>Realizar pedido</h3>

      <div class="flex">
         <div class="inputBox">
            <span>Nombre:</span>
            <input type="text" name="name" placeholder="Ingresa tu nombre" class="box" maxlength="20" required>
         </div>
         <div class="inputBox">
            <span>Teléfono:</span>
            <input type="number" name="number" placeholder="Ingresa tu número" class="box" min="0" max="9999999999" onkeypress="if(this.value.length == 10) return false;" required>
         </div>
         <div class="inputBox">
            <span>Correo electrónico:</span>
            <input type="email" name="email" placeholder="Ingresa tu correo" class="box" maxlength="50" required>
         </div>
         <!-- Added RUC/CI field for invoice -->
         <div class="inputBox">
            <span>RUC/CI (opcional):</span>
            <input type="text" name="ruc" placeholder="Ingresa tu RUC o CI" class="box" maxlength="20">
         </div>
         <div class="inputBox">
            <span>Método de pago:</span>
            <select name="method" class="box" required>
               <option value="cash on delivery">Pago contra entrega</option>
               <option value="credit card">Tarjeta de crédito</option>
               <option value="paytm">eSewa</option>
               <option value="paypal">Khalti</option>
            </select>
         </div>
         <div class="inputBox">
            <span>Dirección línea 1:</span>
            <input type="text" name="flat" placeholder="Ej. Número de apartamento" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Dirección línea 2:</span>
            <input type="text" name="street" placeholder="Nombre de la calle" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Ciudad:</span>
            <input type="text" name="city" placeholder="Ciudad" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Provincia:</span>
            <input type="text" name="state" placeholder="Provincia" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>País:</span>
            <input type="text" name="country" placeholder="País" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Código postal:</span>
            <input type="number" min="0" name="pin_code" placeholder="Ej. 28001" min="0" max="999999" onkeypress="if(this.value.length == 6) return false;" class="box" required>
         </div>
      </div>

      <input type="submit" name="order" class="btn <?= ($grand_total > 1)?'':'disabled'; ?>" value="Realizar pedido">

   </form>

</section>

<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>
