# Nuevos Módulos Agregados al Sistema

Este documento describe los nuevos módulos agregados al sistema de gestión.

## Módulos Implementados

### 1. Módulo de Proveedores
**Ubicación:** `admin/proveedores.php`

**Funcionalidades:**
- Registro de nuevos proveedores con información completa (RUC, dirección, teléfono, email, contacto)
- Listado de proveedores con estado (activo/inactivo)
- Actualización de información de proveedores
- Activación/desactivación de proveedores
- Validación de RUC único

**Archivos relacionados:**
- `admin/proveedores.php` - Gestión principal
- `admin/update_proveedor.php` - Actualización de proveedores

### 2. Módulo de Compras
**Ubicación:** `admin/compras.php`

**Funcionalidades:**
- Registro de compras a proveedores
- Múltiples productos por compra
- Control de estados (pendiente, recibido, cancelado)
- Actualización automática de stock al recibir compras
- Detalle completo de cada compra
- Historial de compras por proveedor

**Archivos relacionados:**
- `admin/compras.php` - Gestión de compras
- `admin/ver_compra.php` - Detalle de compra

**Características especiales:**
- Permite agregar múltiples productos dinámicamente
- Calcula automáticamente el total de la compra
- Actualiza el stock de productos al marcar como "recibido"

### 3. Módulo de Caja (Apertura y Cierre)
**Ubicación:** `admin/caja.php`

**Funcionalidades:**
- Apertura de caja con monto inicial
- Registro de movimientos (ingresos y egresos)
- Cierre de caja con cálculo automático de diferencias
- Vinculación automática de ventas a la caja abierta
- Historial completo de cajas
- Detalle de movimientos por caja

**Archivos relacionados:**
- `admin/caja.php` - Gestión de caja
- `admin/ver_caja.php` - Detalle de caja cerrada

**Características especiales:**
- Solo permite una caja abierta por administrador
- Calcula automáticamente totales de ventas en efectivo y tarjeta
- Muestra diferencias entre monto esperado y contado
- Permite registrar movimientos adicionales (gastos, ingresos extras)

### 4. Módulo de Facturas de Venta
**Ubicación:** `admin/facturas_venta.php`

**Funcionalidades:**
- Generación automática de facturas al realizar pedidos
- Numeración automática de facturas (FAC-YYYYMMDD-XXXXXX)
- Cálculo de subtotal e impuestos (18%)
- Vinculación con pedidos y caja
- Anulación de facturas
- Impresión de facturas en formato profesional
- Detalle completo de cada factura

**Archivos relacionados:**
- `admin/facturas_venta.php` - Listado de facturas
- `admin/ver_factura.php` - Detalle de factura
- `admin/imprimir_factura.php` - Impresión de factura

**Características especiales:**
- Generación automática al completar checkout
- Formato de impresión profesional
- Incluye información completa del cliente
- Vinculación automática con caja abierta

## Base de Datos

### Script SQL
**Ubicación:** `scripts/add_new_modules.sql`

**Tablas creadas:**
1. `proveedores` - Información de proveedores
2. `compras` - Registro de compras
3. `detalle_compras` - Detalle de productos por compra
4. `caja` - Registro de apertura/cierre de caja
5. `movimientos_caja` - Movimientos de caja
6. `facturas_venta` - Facturas emitidas

**Modificaciones a tablas existentes:**
- `products`: Agregados campos `stock`, `stock_minimo`, `categoria`, `codigo`, `costo`
- `orders`: Agregado campo `caja_id` para vincular con caja

### Instalación
Para instalar los nuevos módulos, ejecuta el script SQL:
\`\`\`sql
-- Ejecutar en phpMyAdmin o cliente MySQL
source scripts/add_new_modules.sql;
\`\`\`

O importa el archivo directamente desde phpMyAdmin.

## Integración con el Sistema Existente

### Cambios en archivos existentes:

1. **components/admin_header.php**
   - Agregados enlaces a los nuevos módulos en el menú de navegación

2. **admin/dashboard.php**
   - Agregadas tarjetas de resumen para proveedores, compras, caja y facturas

3. **checkout.php**
   - Modificado para generar factura automáticamente al completar pedido
   - Vincula pedido con caja abierta
   - Calcula subtotal e impuestos

## Flujo de Trabajo

### Proceso de Compra:
1. Registrar proveedor en `admin/proveedores.php`
2. Crear compra en `admin/compras.php` seleccionando proveedor y productos
3. Marcar compra como "recibida" para actualizar stock automáticamente

### Proceso de Venta:
1. Abrir caja en `admin/caja.php` con monto inicial
2. Cliente realiza pedido desde el frontend
3. Se genera automáticamente la factura vinculada a la caja abierta
4. Al final del día, cerrar caja ingresando monto final contado
5. El sistema calcula automáticamente diferencias

### Gestión de Facturas:
1. Las facturas se generan automáticamente al completar checkout
2. Ver listado en `admin/facturas_venta.php`
3. Imprimir factura desde el detalle
4. Anular factura si es necesario

## Características de Seguridad

- Validación de datos en todos los formularios
- Uso de prepared statements para prevenir SQL injection
- Filtrado de entradas con `filter_var()`
- Control de sesiones para acceso administrativo
- Confirmaciones antes de acciones críticas

## Notas Importantes

1. **Stock de Productos**: El stock se actualiza automáticamente al recibir compras
2. **Caja**: Solo puede haber una caja abierta por administrador a la vez
3. **Facturas**: La numeración es automática y única
4. **Impuestos**: Configurado al 18% por defecto (modificable en checkout.php)
5. **Proveedores**: No se eliminan, solo se desactivan para mantener historial

## Soporte y Mantenimiento

Para modificar el porcentaje de impuestos, edita la línea en `checkout.php`:
\`\`\`php
$subtotal = $total_price / 1.18; // Cambiar 1.18 según el impuesto deseado
\`\`\`

Para cambiar el formato de numeración de facturas, edita en `checkout.php`:
\`\`\`php
$numero_factura = 'FAC-' . date('Ymd') . '-' . str_pad($order_id, 6, '0', STR_PAD_LEFT);
