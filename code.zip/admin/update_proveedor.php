<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
}

if(isset($_POST['update'])){

   $pid = $_POST['pid'];
   $nombre = $_POST['nombre'];
   $nombre = filter_var($nombre, FILTER_SANITIZE_STRING);
   $ruc = $_POST['ruc'];
   $ruc = filter_var($ruc, FILTER_SANITIZE_STRING);
   $direccion = $_POST['direccion'];
   $direccion = filter_var($direccion, FILTER_SANITIZE_STRING);
   $telefono = $_POST['telefono'];
   $telefono = filter_var($telefono, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $contacto = $_POST['contacto'];
   $contacto = filter_var($contacto, FILTER_SANITIZE_STRING);

   $update_proveedor = $conn->prepare("UPDATE `proveedores` SET nombre = ?, ruc = ?, direccion = ?, telefono = ?, email = ?, contacto = ? WHERE id = ?");
   $update_proveedor->execute([$nombre, $ruc, $direccion, $telefono, $email, $contacto, $pid]);

   $message[] = '¡Proveedor actualizado exitosamente!';

}

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Actualizar Proveedor</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>

<section class="update-product">

   <h1 class="heading">Actualizar Proveedor</h1>

   <?php
      $update_id = $_GET['update'];
      $select_proveedor = $conn->prepare("SELECT * FROM `proveedores` WHERE id = ?");
      $select_proveedor->execute([$update_id]);
      if($select_proveedor->rowCount() > 0){
         while($fetch_proveedor = $select_proveedor->fetch(PDO::FETCH_ASSOC)){ 
   ?>
   <form action="" method="post">
      <input type="hidden" name="pid" value="<?= $fetch_proveedor['id']; ?>">
      <div class="flex">
         <div class="inputBox">
            <span>Nombre del Proveedor (requerido)</span>
            <input type="text" name="nombre" required class="box" maxlength="100" placeholder="Ingresa el nombre del proveedor" value="<?= $fetch_proveedor['nombre']; ?>">
         </div>
         <div class="inputBox">
            <span>RUC (requerido)</span>
            <input type="text" name="ruc" required class="box" maxlength="20" placeholder="Ingresa el RUC" value="<?= $fetch_proveedor['ruc']; ?>">
         </div>
         <div class="inputBox">
            <span>Dirección (requerida)</span>
            <input type="text" name="direccion" required class="box" maxlength="200" placeholder="Ingresa la dirección" value="<?= $fetch_proveedor['direccion']; ?>">
         </div>
         <div class="inputBox">
            <span>Teléfono (requerido)</span>
            <input type="text" name="telefono" required class="box" maxlength="20" placeholder="Ingresa el teléfono" value="<?= $fetch_proveedor['telefono']; ?>">
         </div>
         <div class="inputBox">
            <span>Email (requerido)</span>
            <input type="email" name="email" required class="box" maxlength="100" placeholder="Ingresa el email" value="<?= $fetch_proveedor['email']; ?>">
         </div>
         <div class="inputBox">
            <span>Persona de Contacto (requerido)</span>
            <input type="text" name="contacto" required class="box" maxlength="100" placeholder="Ingresa el nombre del contacto" value="<?= $fetch_proveedor['contacto']; ?>">
         </div>
      </div>
      <div class="flex-btn">
         <input type="submit" name="update" class="btn" value="Actualizar">
         <a href="proveedores.php" class="option-btn">Volver</a>
      </div>
   </form>
   
   <?php
         }
      }else{
         echo '<p class="empty">¡No se encontró el proveedor!</p>';
      }
   ?>

</section>

<script src="../js/admin_script.js"></script>

</body>
</html>
