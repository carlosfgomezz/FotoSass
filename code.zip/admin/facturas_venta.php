<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
};

// Anular factura
if(isset($_GET['anular'])){
   $factura_id = $_GET['anular'];
   $update_factura = $conn->prepare("UPDATE `facturas_venta` SET estado = 'anulada' WHERE id = ?");
   $update_factura->execute([$factura_id]);
   header('location:facturas_venta.php');
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Facturas de Venta</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>

<section class="show-products">

   <h1 class="heading">Facturas de Venta</h1>

   <!-- Added link to cancelled invoices -->
   <div style="text-align: center; margin-bottom: 20px;">
      <a href="facturas_anuladas.php" class="delete-btn" style="display: inline-block;">
         <i class="fas fa-ban"></i> Ver Facturas Anuladas
      </a>
   </div>

   <div class="box-container">

   <?php
      $select_facturas = $conn->prepare("SELECT * FROM `facturas_venta` WHERE estado = 'emitida' ORDER BY fecha_emision DESC");
      $select_facturas->execute();
      if($select_facturas->rowCount() > 0){
         while($factura = $select_facturas->fetch(PDO::FETCH_ASSOC)){ 
   ?>
   <div class="box">
      <div class="name">Factura: <?= $factura['numero_factura']; ?></div>
      <div class="price">Total: $<span><?= number_format($factura['total'], 2); ?></span></div>
      <div class="details">
         <p><strong>Cliente:</strong> <?= $factura['cliente_nombre']; ?></p>
         <?php if($factura['cliente_ruc']){ ?>
         <p><strong>RUC:</strong> <?= $factura['cliente_ruc']; ?></p>
         <?php } ?>
         <p><strong>Fecha:</strong> <?= date('d/m/Y H:i', strtotime($factura['fecha_emision'])); ?></p>
         <p><strong>Método de Pago:</strong> <?= ucfirst($factura['metodo_pago']); ?></p>
         <p><strong>Subtotal:</strong> $<?= number_format($factura['subtotal'], 2); ?></p>
         <!-- Show IVA instead of generic tax -->
         <p><strong>IVA (<?= $factura['iva_porcentaje']; ?>%):</strong> $<?= number_format($factura['iva_monto'], 2); ?></p>
         <?php if($factura['timbrado']){ ?>
         <p><strong>Timbrado:</strong> <?= $factura['timbrado']; ?></p>
         <?php } ?>
         <p><strong>Estado:</strong> <span style="color: <?= $factura['estado'] == 'emitida' ? 'green' : 'red'; ?>"><?= ucfirst($factura['estado']); ?></span></p>
      </div>
      <div class="flex-btn">
         <a href="ver_factura.php?id=<?= $factura['id']; ?>" class="option-btn">Ver Detalle</a>
         <a href="imprimir_factura.php?id=<?= $factura['id']; ?>" class="btn" target="_blank">Imprimir</a>
         <?php if($factura['estado'] == 'emitida'){ ?>
            <a href="facturas_venta.php?anular=<?= $factura['id']; ?>" class="delete-btn" onclick="return confirm('¿Anular esta factura?');">Anular</a>
         <?php } ?>
      </div>
   </div>
   <?php
         }
      }else{
         echo '<p class="empty">¡No hay facturas registradas aún!</p>';
      }
   ?>
   
   </div>

</section>

<script src="../js/admin_script.js"></script>
   
</body>
</html>
