<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
};

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Facturas Anuladas</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>

<section class="show-products">

   <h1 class="heading">Facturas Anuladas</h1>

   <div class="box-container">

   <?php
      $select_facturas = $conn->prepare("SELECT * FROM `facturas_venta` WHERE estado = 'anulada' ORDER BY fecha_emision DESC");
      $select_facturas->execute();
      if($select_facturas->rowCount() > 0){
         while($factura = $select_facturas->fetch(PDO::FETCH_ASSOC)){ 
   ?>
   <div class="box" style="border: 2px solid red;">
      <div class="name" style="color: red;">Factura: <?= $factura['numero_factura']; ?> - ANULADA</div>
      <div class="price">Total: $<span><?= number_format($factura['total'], 2); ?></span></div>
      <div class="details">
         <p><strong>Cliente:</strong> <?= $factura['cliente_nombre']; ?></p>
         <?php if($factura['cliente_ruc']){ ?>
         <p><strong>RUC:</strong> <?= $factura['cliente_ruc']; ?></p>
         <?php } ?>
         <p><strong>Fecha Emisión:</strong> <?= date('d/m/Y H:i', strtotime($factura['fecha_emision'])); ?></p>
         <p><strong>Método de Pago:</strong> <?= ucfirst($factura['metodo_pago']); ?></p>
         <p><strong>Subtotal:</strong> $<?= number_format($factura['subtotal'], 2); ?></p>
         <p><strong>IVA (<?= $factura['iva_porcentaje']; ?>%):</strong> $<?= number_format($factura['iva_monto'], 2); ?></p>
         <?php if($factura['timbrado']){ ?>
         <p><strong>Timbrado:</strong> <?= $factura['timbrado']; ?></p>
         <?php } ?>
      </div>
      <div class="flex-btn">
         <a href="ver_factura.php?id=<?= $factura['id']; ?>" class="option-btn">Ver Detalle</a>
      </div>
   </div>
   <?php
         }
      }else{
         echo '<p class="empty">¡No hay facturas anuladas!</p>';
      }
   ?>
   
   </div>

</section>

<script src="../js/admin_script.js"></script>
   
</body>
</html>
