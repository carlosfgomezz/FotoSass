<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
};

// Agregar compra
if(isset($_POST['add_compra'])){
   $proveedor_id = $_POST['proveedor_id'];
   $numero_factura = $_POST['numero_factura'];
   $numero_factura = filter_var($numero_factura, FILTER_SANITIZE_STRING);
   $fecha_compra = $_POST['fecha_compra'];
   $observaciones = $_POST['observaciones'];
   $observaciones = filter_var($observaciones, FILTER_SANITIZE_STRING);
   
   // Calcular total
   $total = 0;
   if(isset($_POST['producto_id']) && is_array($_POST['producto_id'])){
      foreach($_POST['producto_id'] as $key => $producto_id){
         $cantidad = $_POST['cantidad'][$key];
         $precio = $_POST['precio_compra'][$key];
         $total += $cantidad * $precio;
      }
   }

   // Insertar compra
   $insert_compra = $conn->prepare("INSERT INTO `compras`(proveedor_id, admin_id, numero_factura, fecha_compra, total, observaciones) VALUES(?,?,?,?,?,?)");
   $insert_compra->execute([$proveedor_id, $admin_id, $numero_factura, $fecha_compra, $total, $observaciones]);
   
   $compra_id = $conn->lastInsertId();
   
   // Insertar detalles de compra
   if(isset($_POST['producto_id']) && is_array($_POST['producto_id'])){
      foreach($_POST['producto_id'] as $key => $producto_id){
         $cantidad = $_POST['cantidad'][$key];
         $precio = $_POST['precio_compra'][$key];
         $subtotal = $cantidad * $precio;
         
         $insert_detalle = $conn->prepare("INSERT INTO `detalle_compras`(compra_id, producto_id, cantidad, precio_compra, subtotal) VALUES(?,?,?,?,?)");
         $insert_detalle->execute([$compra_id, $producto_id, $cantidad, $precio, $subtotal]);
         
         // Actualizar stock del producto
         $update_stock = $conn->prepare("UPDATE `products` SET stock = stock + ? WHERE id = ?");
         $update_stock->execute([$cantidad, $producto_id]);
      }
   }
   
   $message[] = '¡Compra registrada exitosamente!';
}

// Cambiar estado de compra
if(isset($_GET['estado'])){
   $compra_id = $_GET['id'];
   $nuevo_estado = $_GET['estado'];
   $update_compra = $conn->prepare("UPDATE `compras` SET estado = ? WHERE id = ?");
   $update_compra->execute([$nuevo_estado, $compra_id]);
   header('location:compras.php');
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Compras</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>

<section class="add-products">

   <h1 class="heading">Registrar Compra</h1>

   <form action="" method="post">
      <div class="flex">
         <div class="inputBox">
            <span>Proveedor (requerido)</span>
            <select name="proveedor_id" class="box" required>
               <option value="">Selecciona un proveedor</option>
               <?php
                  $select_proveedores = $conn->prepare("SELECT * FROM `proveedores` WHERE estado = 'activo' ORDER BY nombre");
                  $select_proveedores->execute();
                  while($proveedor = $select_proveedores->fetch(PDO::FETCH_ASSOC)){
                     echo '<option value="'.$proveedor['id'].'">'.$proveedor['nombre'].'</option>';
                  }
               ?>
            </select>
         </div>
         <div class="inputBox">
            <span>Número de Factura (requerido)</span>
            <input type="text" class="box" required maxlength="50" placeholder="Ingresa el número de factura" name="numero_factura">
         </div>
         <div class="inputBox">
            <span>Fecha de Compra (requerida)</span>
            <input type="date" class="box" required name="fecha_compra" value="<?= date('Y-m-d'); ?>">
         </div>
         <div class="inputBox">
            <span>Observaciones</span>
            <textarea name="observaciones" placeholder="Observaciones adicionales" class="box" maxlength="500" cols="30" rows="5"></textarea>
         </div>
      </div>

      <h3>Productos</h3>
      <div id="productos-container">
         <div class="producto-item flex">
            <div class="inputBox">
               <span>Producto</span>
               <select name="producto_id[]" class="box" required>
                  <option value="">Selecciona un producto</option>
                  <?php
                     $select_products = $conn->prepare("SELECT * FROM `products` ORDER BY name");
                     $select_products->execute();
                     while($product = $select_products->fetch(PDO::FETCH_ASSOC)){
                        echo '<option value="'.$product['id'].'">'.$product['name'].'</option>';
                     }
                  ?>
               </select>
            </div>
            <div class="inputBox">
               <span>Cantidad</span>
               <input type="number" name="cantidad[]" class="box" required min="1" value="1">
            </div>
            <div class="inputBox">
               <span>Precio de Compra</span>
               <input type="number" name="precio_compra[]" class="box" required min="0" step="0.01" value="0">
            </div>
         </div>
      </div>
      
      <button type="button" class="option-btn" onclick="agregarProducto()">+ Agregar Producto</button>
      <input type="submit" value="Registrar Compra" class="btn" name="add_compra">
   </form>

</section>

<section class="show-products">

   <h1 class="heading">Compras Registradas</h1>

   <div class="box-container">

   <?php
      $select_compras = $conn->prepare("SELECT c.*, p.nombre as proveedor_nombre FROM `compras` c 
                                        LEFT JOIN `proveedores` p ON c.proveedor_id = p.id 
                                        ORDER BY c.fecha_compra DESC");
      $select_compras->execute();
      if($select_compras->rowCount() > 0){
         while($fetch_compra = $select_compras->fetch(PDO::FETCH_ASSOC)){ 
   ?>
   <div class="box">
      <div class="name">Factura: <?= $fetch_compra['numero_factura']; ?></div>
      <div class="price">Total: $<span><?= number_format($fetch_compra['total'], 2); ?></span></div>
      <div class="details">
         <p><strong>Proveedor:</strong> <?= $fetch_compra['proveedor_nombre']; ?></p>
         <p><strong>Fecha:</strong> <?= date('d/m/Y', strtotime($fetch_compra['fecha_compra'])); ?></p>
         <p><strong>Estado:</strong> <span style="color: <?= $fetch_compra['estado'] == 'recibido' ? 'green' : ($fetch_compra['estado'] == 'pendiente' ? 'orange' : 'red'); ?>"><?= ucfirst($fetch_compra['estado']); ?></span></p>
         <?php if($fetch_compra['observaciones']){ ?>
         <p><strong>Observaciones:</strong> <?= $fetch_compra['observaciones']; ?></p>
         <?php } ?>
      </div>
      <div class="flex-btn">
         <a href="ver_compra.php?id=<?= $fetch_compra['id']; ?>" class="option-btn">Ver Detalle</a>
         <?php if($fetch_compra['estado'] == 'pendiente'){ ?>
            <a href="compras.php?id=<?= $fetch_compra['id']; ?>&estado=recibido" class="btn" onclick="return confirm('¿Marcar como recibido?');">Recibir</a>
         <?php } ?>
      </div>
   </div>
   <?php
         }
      }else{
         echo '<p class="empty">¡No hay compras registradas aún!</p>';
      }
   ?>
   
   </div>

</section>

<script src="../js/admin_script.js"></script>

<script>
function agregarProducto() {
   const container = document.getElementById('productos-container');
   const productoItem = container.querySelector('.producto-item').cloneNode(true);
   productoItem.querySelectorAll('input').forEach(input => input.value = input.type === 'number' ? (input.min || '0') : '');
   productoItem.querySelectorAll('select').forEach(select => select.selectedIndex = 0);
   container.appendChild(productoItem);
}
</script>
   
</body>
</html>
