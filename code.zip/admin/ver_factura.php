<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
}

$factura_id = $_GET['id'];

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Detalle de Factura</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>

<section class="orders">

   <h1 class="heading">Detalle de Factura</h1>

   <?php
      $select_factura = $conn->prepare("SELECT f.*, o.total_products, o.address 
                                        FROM `facturas_venta` f 
                                        LEFT JOIN `orders` o ON f.order_id = o.id 
                                        WHERE f.id = ?");
      $select_factura->execute([$factura_id]);
      if($select_factura->rowCount() > 0){
         $factura = $select_factura->fetch(PDO::FETCH_ASSOC);
   ?>

   <div class="box-container">
      <div class="box">
         <h3>Información de la Factura</h3>
         <p><strong>Número:</strong> <?= $factura['numero_factura']; ?></p>
         <p><strong>Fecha de Emisión:</strong> <?= date('d/m/Y H:i', strtotime($factura['fecha_emision'])); ?></p>
         <p><strong>Estado:</strong> <?= ucfirst($factura['estado']); ?></p>
         <p><strong>Método de Pago:</strong> <?= ucfirst($factura['metodo_pago']); ?></p>
         <!-- Added timbrado and payment terms -->
         <?php if($factura['timbrado']){ ?>
         <p><strong>Timbrado:</strong> <?= $factura['timbrado']; ?></p>
         <?php } ?>
         <p><strong>Condiciones de Venta:</strong> <?= $factura['condiciones_venta']; ?></p>
      </div>

      <div class="box">
         <h3>Información del Cliente</h3>
         <p><strong>Nombre:</strong> <?= $factura['cliente_nombre']; ?></p>
         <?php if($factura['cliente_ruc']){ ?>
         <p><strong>RUC:</strong> <?= $factura['cliente_ruc']; ?></p>
         <?php } ?>
         <?php if($factura['cliente_direccion']){ ?>
         <p><strong>Dirección:</strong> <?= $factura['cliente_direccion']; ?></p>
         <?php }elseif($factura['address']){ ?>
         <p><strong>Dirección:</strong> <?= $factura['address']; ?></p>
         <?php } ?>
      </div>

      <div class="box">
         <h3>Totales</h3>
         <p><strong>Subtotal:</strong> $<?= number_format($factura['subtotal'], 2); ?></p>
         <!-- Show IVA with percentage -->
         <p><strong>IVA (<?= $factura['iva_porcentaje']; ?>%):</strong> $<?= number_format($factura['iva_monto'], 2); ?></p>
         <p><strong>Total:</strong> $<?= number_format($factura['total'], 2); ?></p>
         <!-- Show total in words -->
         <?php if($factura['total_letras']){ ?>
         <p><strong>Total en Letras:</strong> <?= $factura['total_letras']; ?></p>
         <?php } ?>
      </div>
   </div>

   <h2 class="heading">Productos</h2>

   <div class="box-container">
      <?php
         $productos = explode(' - ', $factura['total_products']);
         foreach($productos as $producto){
            if(!empty($producto)){
               echo '<div class="box"><p>'.$producto.'</p></div>';
            }
         }
      ?>
   </div>

   <div class="flex-btn">
      <a href="facturas_venta.php" class="option-btn">Volver</a>
      <a href="imprimir_factura.php?id=<?= $factura_id; ?>" class="btn" target="_blank">Imprimir</a>
   </div>

   <?php
      }else{
         echo '<p class="empty">¡No se encontró la factura!</p>';
      }
   ?>

</section>

<script src="../js/admin_script.js"></script>

</body>
</html>
