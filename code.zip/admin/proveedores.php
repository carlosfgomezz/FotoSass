<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
};

// Agregar proveedor
if(isset($_POST['add_proveedor'])){
   $nombre = $_POST['nombre'];
   $nombre = filter_var($nombre, FILTER_SANITIZE_STRING);
   $ruc = $_POST['ruc'];
   $ruc = filter_var($ruc, FILTER_SANITIZE_STRING);
   $direccion = $_POST['direccion'];
   $direccion = filter_var($direccion, FILTER_SANITIZE_STRING);
   $telefono = $_POST['telefono'];
   $telefono = filter_var($telefono, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $contacto = $_POST['contacto'];
   $contacto = filter_var($contacto, FILTER_SANITIZE_STRING);

   $select_proveedor = $conn->prepare("SELECT * FROM `proveedores` WHERE ruc = ?");
   $select_proveedor->execute([$ruc]);

   if($select_proveedor->rowCount() > 0){
      $message[] = '¡El RUC del proveedor ya existe!';
   }else{
      $insert_proveedor = $conn->prepare("INSERT INTO `proveedores`(nombre, ruc, direccion, telefono, email, contacto) VALUES(?,?,?,?,?,?)");
      $insert_proveedor->execute([$nombre, $ruc, $direccion, $telefono, $email, $contacto]);
      $message[] = '¡Nuevo proveedor añadido!';
   }
}

// Eliminar proveedor
if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $update_proveedor = $conn->prepare("UPDATE `proveedores` SET estado = 'inactivo' WHERE id = ?");
   $update_proveedor->execute([$delete_id]);
   header('location:proveedores.php');
}

// Activar proveedor
if(isset($_GET['activate'])){
   $activate_id = $_GET['activate'];
   $update_proveedor = $conn->prepare("UPDATE `proveedores` SET estado = 'activo' WHERE id = ?");
   $update_proveedor->execute([$activate_id]);
   header('location:proveedores.php');
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Proveedores</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>

<section class="add-products">

   <h1 class="heading">Añadir Proveedor</h1>

   <form action="" method="post">
      <div class="flex">
         <div class="inputBox">
            <span>Nombre del Proveedor (requerido)</span>
            <input type="text" class="box" required maxlength="100" placeholder="Ingresa el nombre del proveedor" name="nombre">
         </div>
         <div class="inputBox">
            <span>RUC (requerido)</span>
            <input type="text" class="box" required maxlength="20" placeholder="Ingresa el RUC" name="ruc">
         </div>
         <div class="inputBox">
            <span>Dirección (requerida)</span>
            <input type="text" class="box" required maxlength="200" placeholder="Ingresa la dirección" name="direccion">
         </div>
         <div class="inputBox">
            <span>Teléfono (requerido)</span>
            <input type="text" class="box" required maxlength="20" placeholder="Ingresa el teléfono" name="telefono">
         </div>
         <div class="inputBox">
            <span>Email (requerido)</span>
            <input type="email" class="box" required maxlength="100" placeholder="Ingresa el email" name="email">
         </div>
         <div class="inputBox">
            <span>Persona de Contacto (requerido)</span>
            <input type="text" class="box" required maxlength="100" placeholder="Ingresa el nombre del contacto" name="contacto">
         </div>
      </div>
      
      <input type="submit" value="Añadir Proveedor" class="btn" name="add_proveedor">
   </form>

</section>

<section class="show-products">

   <h1 class="heading">Proveedores Registrados</h1>

   <div class="box-container">

   <?php
      $select_proveedores = $conn->prepare("SELECT * FROM `proveedores` ORDER BY estado DESC, nombre ASC");
      $select_proveedores->execute();
      if($select_proveedores->rowCount() > 0){
         while($fetch_proveedor = $select_proveedores->fetch(PDO::FETCH_ASSOC)){ 
   ?>
   <div class="box">
      <div class="name"><?= $fetch_proveedor['nombre']; ?></div>
      <div class="price">RUC: <span><?= $fetch_proveedor['ruc']; ?></span></div>
      <div class="details">
         <p><strong>Dirección:</strong> <?= $fetch_proveedor['direccion']; ?></p>
         <p><strong>Teléfono:</strong> <?= $fetch_proveedor['telefono']; ?></p>
         <p><strong>Email:</strong> <?= $fetch_proveedor['email']; ?></p>
         <p><strong>Contacto:</strong> <?= $fetch_proveedor['contacto']; ?></p>
         <p><strong>Estado:</strong> <span style="color: <?= $fetch_proveedor['estado'] == 'activo' ? 'green' : 'red'; ?>"><?= ucfirst($fetch_proveedor['estado']); ?></span></p>
      </div>
      <div class="flex-btn">
         <a href="update_proveedor.php?update=<?= $fetch_proveedor['id']; ?>" class="option-btn">Actualizar</a>
         <?php if($fetch_proveedor['estado'] == 'activo'){ ?>
            <a href="proveedores.php?delete=<?= $fetch_proveedor['id']; ?>" class="delete-btn" onclick="return confirm('¿Desactivar este proveedor?');">Desactivar</a>
         <?php }else{ ?>
            <a href="proveedores.php?activate=<?= $fetch_proveedor['id']; ?>" class="option-btn" onclick="return confirm('¿Activar este proveedor?');">Activar</a>
         <?php } ?>
      </div>
   </div>
   <?php
         }
      }else{
         echo '<p class="empty">¡No hay proveedores registrados aún!</p>';
      }
   ?>
   
   </div>

</section>

<script src="../js/admin_script.js"></script>
   
</body>
</html>
