<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
};

// Actualizar configuración
if(isset($_POST['actualizar'])){
   $nombre_empresa = $_POST['nombre_empresa'];
   $nombre_empresa = filter_var($nombre_empresa, FILTER_SANITIZE_STRING);
   $ruc_empresa = $_POST['ruc_empresa'];
   $ruc_empresa = filter_var($ruc_empresa, FILTER_SANITIZE_STRING);
   $direccion_empresa = $_POST['direccion_empresa'];
   $direccion_empresa = filter_var($direccion_empresa, FILTER_SANITIZE_STRING);
   $telefono_empresa = $_POST['telefono_empresa'];
   $telefono_empresa = filter_var($telefono_empresa, FILTER_SANITIZE_STRING);
   $email_empresa = $_POST['email_empresa'];
   $email_empresa = filter_var($email_empresa, FILTER_SANITIZE_STRING);
   $timbrado_actual = $_POST['timbrado_actual'];
   $timbrado_actual = filter_var($timbrado_actual, FILTER_SANITIZE_STRING);
   $fecha_inicio_timbrado = $_POST['fecha_inicio_timbrado'];
   $fecha_fin_timbrado = $_POST['fecha_fin_timbrado'];
   $iva_porcentaje = $_POST['iva_porcentaje'];

   $update_config = $conn->prepare("UPDATE `configuracion_sistema` SET 
      nombre_empresa = ?, ruc_empresa = ?, direccion_empresa = ?, 
      telefono_empresa = ?, email_empresa = ?, timbrado_actual = ?,
      fecha_inicio_timbrado = ?, fecha_fin_timbrado = ?, iva_porcentaje = ?
      WHERE id = 1");
   $update_config->execute([$nombre_empresa, $ruc_empresa, $direccion_empresa, 
      $telefono_empresa, $email_empresa, $timbrado_actual, 
      $fecha_inicio_timbrado, $fecha_fin_timbrado, $iva_porcentaje]);
   
   $message[] = '¡Configuración actualizada correctamente!';
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Configuración del Sistema</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>

<section class="add-products">

   <h1 class="heading">Configuración del Sistema</h1>

   <?php
      $select_config = $conn->prepare("SELECT * FROM `configuracion_sistema` WHERE id = 1");
      $select_config->execute();
      $config = $select_config->fetch(PDO::FETCH_ASSOC);
   ?>

   <form action="" method="post" enctype="multipart/form-data">
      <h3>Datos de la Empresa</h3>
      <input type="text" name="nombre_empresa" value="<?= $config['nombre_empresa']; ?>" class="box" required placeholder="Nombre de la empresa">
      <input type="text" name="ruc_empresa" value="<?= $config['ruc_empresa']; ?>" class="box" required placeholder="RUC de la empresa">
      <input type="text" name="direccion_empresa" value="<?= $config['direccion_empresa']; ?>" class="box" required placeholder="Dirección">
      <input type="text" name="telefono_empresa" value="<?= $config['telefono_empresa']; ?>" class="box" required placeholder="Teléfono">
      <input type="email" name="email_empresa" value="<?= $config['email_empresa']; ?>" class="box" placeholder="Email">
      
      <h3>Configuración de Facturación</h3>
      <input type="text" name="timbrado_actual" value="<?= $config['timbrado_actual']; ?>" class="box" required placeholder="Número de Timbrado">
      <div class="flex">
         <div class="inputBox">
            <span>Fecha Inicio Timbrado:</span>
            <input type="date" name="fecha_inicio_timbrado" value="<?= $config['fecha_inicio_timbrado']; ?>" class="box" required>
         </div>
         <div class="inputBox">
            <span>Fecha Fin Timbrado:</span>
            <input type="date" name="fecha_fin_timbrado" value="<?= $config['fecha_fin_timbrado']; ?>" class="box" required>
         </div>
      </div>
      <input type="number" step="0.01" name="iva_porcentaje" value="<?= $config['iva_porcentaje']; ?>" class="box" required placeholder="Porcentaje de IVA (%)">
      
      <input type="submit" value="Actualizar Configuración" class="btn" name="actualizar">
   </form>

</section>

<script src="../js/admin_script.js"></script>
   
</body>
</html>
