<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
}

$caja_id = $_GET['id'];

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Detalle de Caja</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>

<section class="orders">

   <h1 class="heading">Detalle de Caja</h1>

   <?php
      $select_caja = $conn->prepare("SELECT * FROM `caja` WHERE id = ?");
      $select_caja->execute([$caja_id]);
      if($select_caja->rowCount() > 0){
         $caja = $select_caja->fetch(PDO::FETCH_ASSOC);
   ?>

   <div class="box-container">
      <div class="box">
         <h3>Información General</h3>
         <p><strong>Fecha Apertura:</strong> <?= date('d/m/Y H:i', strtotime($caja['fecha_apertura'])); ?></p>
         <p><strong>Fecha Cierre:</strong> <?= date('d/m/Y H:i', strtotime($caja['fecha_cierre'])); ?></p>
         <p><strong>Estado:</strong> <?= ucfirst($caja['estado']); ?></p>
      </div>

      <div class="box">
         <h3>Montos</h3>
         <p><strong>Monto Inicial:</strong> $<?= number_format($caja['monto_inicial'], 2); ?></p>
         <p><strong>Monto Final:</strong> $<?= number_format($caja['monto_final'], 2); ?></p>
         <p><strong>Total Ventas:</strong> $<?= number_format($caja['total_ventas'], 2); ?></p>
         <p><strong>Total Efectivo:</strong> $<?= number_format($caja['total_efectivo'], 2); ?></p>
         <p><strong>Total Tarjeta:</strong> $<?= number_format($caja['total_tarjeta'], 2); ?></p>
         <p><strong>Diferencia:</strong> <span style="color: <?= $caja['diferencia'] == 0 ? 'green' : 'red'; ?>">$<?= number_format($caja['diferencia'], 2); ?></span></p>
      </div>

      <?php if($caja['observaciones']){ ?>
      <div class="box">
         <h3>Observaciones</h3>
         <p><?= $caja['observaciones']; ?></p>
      </div>
      <?php } ?>
   </div>

   <h2 class="heading">Movimientos</h2>

   <div class="box-container">
      <?php
         $select_movimientos = $conn->prepare("SELECT * FROM `movimientos_caja` WHERE caja_id = ? ORDER BY fecha");
         $select_movimientos->execute([$caja_id]);
         if($select_movimientos->rowCount() > 0){
            while($movimiento = $select_movimientos->fetch(PDO::FETCH_ASSOC)){
      ?>
      <div class="box">
         <p><strong>Concepto:</strong> <?= $movimiento['concepto']; ?></p>
         <p><strong>Tipo:</strong> <?= ucfirst($movimiento['tipo']); ?></p>
         <p><strong>Monto:</strong> <span style="color: <?= $movimiento['tipo'] == 'ingreso' ? 'green' : 'red'; ?>">
            <?= $movimiento['tipo'] == 'ingreso' ? '+' : '-'; ?>$<?= number_format($movimiento['monto'], 2); ?>
         </span></p>
         <p><strong>Fecha:</strong> <?= date('d/m/Y H:i', strtotime($movimiento['fecha'])); ?></p>
         <?php if($movimiento['referencia']){ ?>
         <p><strong>Referencia:</strong> <?= $movimiento['referencia']; ?></p>
         <?php } ?>
      </div>
      <?php
            }
         }else{
            echo '<p class="empty">No hay movimientos registrados</p>';
         }
      ?>
   </div>

   <div class="flex-btn">
      <a href="caja.php" class="option-btn">Volver</a>
   </div>

   <?php
      }else{
         echo '<p class="empty">¡No se encontró la caja!</p>';
      }
   ?>

</section>

<script src="../js/admin_script.js"></script>

</body>
</html>
