<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
}

$compra_id = $_GET['id'];

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Detalle de Compra</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>

<section class="orders">

   <h1 class="heading">Detalle de Compra</h1>

   <?php
      $select_compra = $conn->prepare("SELECT c.*, p.nombre as proveedor_nombre, p.ruc, p.direccion, p.telefono 
                                       FROM `compras` c 
                                       LEFT JOIN `proveedores` p ON c.proveedor_id = p.id 
                                       WHERE c.id = ?");
      $select_compra->execute([$compra_id]);
      if($select_compra->rowCount() > 0){
         $fetch_compra = $select_compra->fetch(PDO::FETCH_ASSOC);
   ?>

   <div class="box-container">
      <div class="box">
         <h3>Información de la Compra</h3>
         <p><strong>Número de Factura:</strong> <?= $fetch_compra['numero_factura']; ?></p>
         <p><strong>Fecha:</strong> <?= date('d/m/Y', strtotime($fetch_compra['fecha_compra'])); ?></p>
         <p><strong>Estado:</strong> <?= ucfirst($fetch_compra['estado']); ?></p>
         <p><strong>Total:</strong> $<?= number_format($fetch_compra['total'], 2); ?></p>
         <?php if($fetch_compra['observaciones']){ ?>
         <p><strong>Observaciones:</strong> <?= $fetch_compra['observaciones']; ?></p>
         <?php } ?>
      </div>

      <div class="box">
         <h3>Información del Proveedor</h3>
         <p><strong>Nombre:</strong> <?= $fetch_compra['proveedor_nombre']; ?></p>
         <p><strong>RUC:</strong> <?= $fetch_compra['ruc']; ?></p>
         <p><strong>Dirección:</strong> <?= $fetch_compra['direccion']; ?></p>
         <p><strong>Teléfono:</strong> <?= $fetch_compra['telefono']; ?></p>
      </div>
   </div>

   <h2 class="heading">Productos</h2>

   <div class="box-container">
      <?php
         $select_detalles = $conn->prepare("SELECT d.*, p.name as producto_nombre 
                                           FROM `detalle_compras` d 
                                           LEFT JOIN `products` p ON d.producto_id = p.id 
                                           WHERE d.compra_id = ?");
         $select_detalles->execute([$compra_id]);
         while($detalle = $select_detalles->fetch(PDO::FETCH_ASSOC)){
      ?>
      <div class="box">
         <p><strong>Producto:</strong> <?= $detalle['producto_nombre']; ?></p>
         <p><strong>Cantidad:</strong> <?= $detalle['cantidad']; ?></p>
         <p><strong>Precio Unitario:</strong> $<?= number_format($detalle['precio_compra'], 2); ?></p>
         <p><strong>Subtotal:</strong> $<?= number_format($detalle['subtotal'], 2); ?></p>
      </div>
      <?php } ?>
   </div>

   <div class="flex-btn">
      <a href="compras.php" class="option-btn">Volver</a>
   </div>

   <?php
      }else{
         echo '<p class="empty">¡No se encontró la compra!</p>';
      }
   ?>

</section>

<script src="../js/admin_script.js"></script>

</body>
</html>
