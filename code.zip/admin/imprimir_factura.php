<?php

include '../components/connect.php';
include '../components/numero_a_letras.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
}

$factura_id = $_GET['id'];

$select_factura = $conn->prepare("SELECT f.*, o.total_products, o.address 
                                  FROM `facturas_venta` f 
                                  LEFT JOIN `orders` o ON f.order_id = o.id 
                                  WHERE f.id = ?");
$select_factura->execute([$factura_id]);
$factura = $select_factura->fetch(PDO::FETCH_ASSOC);

$select_config = $conn->prepare("SELECT * FROM `configuracion_sistema` WHERE id = 1");
$select_config->execute();
$config = $select_config->fetch(PDO::FETCH_ASSOC);

$total_letras = numeroALetras($factura['total']);

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Factura <?= $factura['numero_factura']; ?></title>
   <style>
      * {
         margin: 0;
         padding: 0;
         box-sizing: border-box;
      }
      body {
         font-family: 'Courier New', monospace;
         padding: 20px;
         max-width: 800px;
         margin: 0 auto;
         font-size: 12px;
      }
      .header {
         text-align: center;
         margin-bottom: 20px;
         border: 2px solid #000;
         padding: 15px;
      }
      .header h1 {
         font-size: 20px;
         margin-bottom: 5px;
      }
      .header p {
         margin: 3px 0;
         font-size: 11px;
      }
      .factura-info {
         border: 2px solid #000;
         padding: 10px;
         margin-bottom: 15px;
      }
      .factura-info h2 {
         text-align: center;
         font-size: 16px;
         margin-bottom: 10px;
         background: #000;
         color: #fff;
         padding: 5px;
      }
      .info-row {
         display: flex;
         justify-content: space-between;
         padding: 3px 0;
         border-bottom: 1px dotted #999;
      }
      .info-section {
         margin-bottom: 15px;
         border: 1px solid #000;
         padding: 10px;
      }
      .info-section h3 {
         font-size: 13px;
         margin-bottom: 8px;
         text-decoration: underline;
      }
      .productos {
         margin: 15px 0;
      }
      .productos table {
         width: 100%;
         border-collapse: collapse;
         border: 2px solid #000;
      }
      .productos th, .productos td {
         border: 1px solid #000;
         padding: 8px 5px;
         text-align: left;
         font-size: 11px;
      }
      .productos th {
         background: #f0f0f0;
         font-weight: bold;
      }
      .totales {
         margin-top: 15px;
         border: 2px solid #000;
         padding: 10px;
      }
      .totales p {
         padding: 5px 0;
         display: flex;
         justify-content: space-between;
         border-bottom: 1px dotted #999;
      }
      .totales .total-final {
         font-size: 14px;
         font-weight: bold;
         border-top: 2px solid #000;
         border-bottom: 2px solid #000;
         padding: 8px 0;
         margin-top: 5px;
         background: #f0f0f0;
      }
      /* Added style for total in words */
      .total-letras {
         margin-top: 10px;
         padding: 10px;
         border: 2px solid #000;
         background: #f9f9f9;
         font-weight: bold;
         text-align: center;
      }
      .timbrado-info {
         margin-top: 15px;
         padding: 10px;
         border: 1px solid #000;
         font-size: 10px;
         text-align: center;
      }
      .footer {
         margin-top: 30px;
         text-align: center;
         font-size: 10px;
         border-top: 1px solid #000;
         padding-top: 10px;
      }
      .anulada {
         position: fixed;
         top: 50%;
         left: 50%;
         transform: translate(-50%, -50%) rotate(-45deg);
         font-size: 100px;
         color: rgba(255, 0, 0, 0.3);
         font-weight: bold;
         z-index: 1000;
         pointer-events: none;
      }
      @media print {
         body {
            padding: 0;
         }
         .no-print {
            display: none;
         }
      }
   </style>
</head>
<body>

   <!-- Show ANULADA watermark if invoice is cancelled -->
   <?php if($factura['estado'] == 'anulada'){ ?>
   <div class="anulada">ANULADA</div>
   <?php } ?>

   <div class="header">
      <h1><?= $config['nombre_empresa']; ?></h1>
      <p><strong>RUC:</strong> <?= $config['ruc_empresa']; ?></p>
      <p><?= $config['direccion_empresa']; ?></p>
      <p><strong>Tel:</strong> <?= $config['telefono_empresa']; ?></p>
      <?php if($config['email_empresa']){ ?>
      <p><strong>Email:</strong> <?= $config['email_empresa']; ?></p>
      <?php } ?>
   </div>

   <div class="factura-info">
      <h2>FACTURA DE VENTA</h2>
      <div class="info-row">
         <span><strong>N° Factura:</strong></span>
         <span><?= $factura['numero_factura']; ?></span>
      </div>
      <!-- Added Timbrado -->
      <div class="info-row">
         <span><strong>Timbrado:</strong></span>
         <span><?= $factura['timbrado'] ? $factura['timbrado'] : $config['timbrado_actual']; ?></span>
      </div>
      <div class="info-row">
         <span><strong>Fecha de Emisión:</strong></span>
         <span><?= date('d/m/Y H:i', strtotime($factura['fecha_emision'])); ?></span>
      </div>
      <!-- Added payment terms -->
      <div class="info-row">
         <span><strong>Condiciones de Venta:</strong></span>
         <span><?= $factura['condiciones_venta'] ? $factura['condiciones_venta'] : 'CONTADO'; ?></span>
      </div>
   </div>

   <div class="info-section">
      <h3>DATOS DEL CLIENTE</h3>
      <div class="info-row">
         <span><strong>Nombre/Razón Social:</strong></span>
         <span><?= $factura['cliente_nombre']; ?></span>
      </div>
      <?php if($factura['cliente_ruc']){ ?>
      <div class="info-row">
         <span><strong>RUC/CI:</strong></span>
         <span><?= $factura['cliente_ruc']; ?></span>
      </div>
      <?php } ?>
      <?php if($factura['cliente_direccion']){ ?>
      <div class="info-row">
         <span><strong>Dirección:</strong></span>
         <span><?= $factura['cliente_direccion']; ?></span>
      </div>
      <?php }elseif($factura['address']){ ?>
      <div class="info-row">
         <span><strong>Dirección:</strong></span>
         <span><?= $factura['address']; ?></span>
      </div>
      <?php } ?>
   </div>

   <div class="productos">
      <table>
         <thead>
            <tr>
               <th style="width: 60%;">DESCRIPCIÓN</th>
               <th style="width: 15%;">CANT.</th>
               <th style="width: 25%;">PRECIO</th>
            </tr>
         </thead>
         <tbody>
            <?php
               $productos = explode(' - ', $factura['total_products']);
               foreach($productos as $producto){
                  if(!empty($producto)){
                     echo '<tr><td colspan="3">'.$producto.'</td></tr>';
                  }
               }
            ?>
         </tbody>
      </table>
   </div>

   <div class="totales">
      <p>
         <span><strong>Subtotal:</strong></span>
         <span>$<?= number_format($factura['subtotal'], 2); ?></span>
      </p>
      <!-- Show IVA with percentage -->
      <p>
         <span><strong>IVA (<?= $factura['iva_porcentaje']; ?>%):</strong></span>
         <span>$<?= number_format($factura['iva_monto'], 2); ?></span>
      </p>
      <p class="total-final">
         <span><strong>TOTAL A PAGAR:</strong></span>
         <span><strong>$<?= number_format($factura['total'], 2); ?></strong></span>
      </p>
   </div>

   <!-- Added total in words -->
   <div class="total-letras">
      <p>SON: <?= $total_letras; ?></p>
   </div>

   <div class="timbrado-info">
      <p><strong>Timbrado N°:</strong> <?= $factura['timbrado'] ? $factura['timbrado'] : $config['timbrado_actual']; ?></p>
      <p><strong>Válido desde:</strong> <?= date('d/m/Y', strtotime($config['fecha_inicio_timbrado'])); ?> 
         <strong>hasta:</strong> <?= date('d/m/Y', strtotime($config['fecha_fin_timbrado'])); ?></p>
   </div>

   <div class="footer">
      <p><strong>Método de Pago:</strong> <?= strtoupper($factura['metodo_pago']); ?></p>
      <p>Gracias por su compra - <?= $config['nombre_empresa']; ?></p>
      <?php if($factura['estado'] == 'anulada'){ ?>
      <p style="color: red; font-weight: bold; margin-top: 10px;">*** FACTURA ANULADA ***</p>
      <?php } ?>
   </div>

   <div class="no-print" style="text-align: center; margin-top: 30px;">
      <button onclick="window.print()" style="padding: 10px 20px; font-size: 16px; cursor: pointer;">Imprimir</button>
      <button onclick="window.close()" style="padding: 10px 20px; font-size: 16px; cursor: pointer; margin-left: 10px;">Cerrar</button>
   </div>

</body>
</html>
