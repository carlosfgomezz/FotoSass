<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
};

// Abrir caja
if(isset($_POST['abrir_caja'])){
   // Verificar si hay una caja abierta
   $check_caja = $conn->prepare("SELECT * FROM `caja` WHERE admin_id = ? AND estado = 'abierta'");
   $check_caja->execute([$admin_id]);
   
   if($check_caja->rowCount() > 0){
      $message[] = '¡Ya tienes una caja abierta!';
   }else{
      $monto_inicial = $_POST['monto_inicial'];
      $monto_inicial = filter_var($monto_inicial, FILTER_SANITIZE_STRING);
      
      $insert_caja = $conn->prepare("INSERT INTO `caja`(admin_id, fecha_apertura, monto_inicial) VALUES(?,NOW(),?)");
      $insert_caja->execute([$admin_id, $monto_inicial]);
      $message[] = '¡Caja abierta exitosamente!';
   }
}

// Cerrar caja
if(isset($_POST['cerrar_caja'])){
   $caja_id = $_POST['caja_id'];
   $monto_final = $_POST['monto_final'];
   $monto_final = filter_var($monto_final, FILTER_SANITIZE_STRING);
   $observaciones = $_POST['observaciones'];
   $observaciones = filter_var($observaciones, FILTER_SANITIZE_STRING);
   
   // Obtener totales de ventas
   $select_ventas = $conn->prepare("SELECT SUM(total_price) as total_ventas, 
                                            SUM(CASE WHEN method = 'efectivo' THEN total_price ELSE 0 END) as total_efectivo,
                                            SUM(CASE WHEN method = 'tarjeta' THEN total_price ELSE 0 END) as total_tarjeta
                                     FROM `orders` WHERE caja_id = ?");
   $select_ventas->execute([$caja_id]);
   $ventas = $select_ventas->fetch(PDO::FETCH_ASSOC);
   
   $total_ventas = $ventas['total_ventas'] ?? 0;
   $total_efectivo = $ventas['total_efectivo'] ?? 0;
   $total_tarjeta = $ventas['total_tarjeta'] ?? 0;
   
   // Calcular diferencia
   $select_caja = $conn->prepare("SELECT monto_inicial FROM `caja` WHERE id = ?");
   $select_caja->execute([$caja_id]);
   $caja_data = $select_caja->fetch(PDO::FETCH_ASSOC);
   $monto_esperado = $caja_data['monto_inicial'] + $total_efectivo;
   $diferencia = $monto_final - $monto_esperado;
   
   $update_caja = $conn->prepare("UPDATE `caja` SET fecha_cierre = NOW(), monto_final = ?, total_ventas = ?, total_efectivo = ?, total_tarjeta = ?, diferencia = ?, estado = 'cerrada', observaciones = ? WHERE id = ?");
   $update_caja->execute([$monto_final, $total_ventas, $total_efectivo, $total_tarjeta, $diferencia, $observaciones, $caja_id]);
   
   $message[] = '¡Caja cerrada exitosamente!';
}

// Agregar movimiento
if(isset($_POST['add_movimiento'])){
   $caja_id = $_POST['caja_id'];
   $tipo = $_POST['tipo'];
   $concepto = $_POST['concepto'];
   $concepto = filter_var($concepto, FILTER_SANITIZE_STRING);
   $monto = $_POST['monto'];
   $monto = filter_var($monto, FILTER_SANITIZE_STRING);
   $referencia = $_POST['referencia'];
   $referencia = filter_var($referencia, FILTER_SANITIZE_STRING);
   
   $insert_movimiento = $conn->prepare("INSERT INTO `movimientos_caja`(caja_id, tipo, concepto, monto, referencia) VALUES(?,?,?,?,?)");
   $insert_movimiento->execute([$caja_id, $tipo, $concepto, $monto, $referencia]);
   $message[] = '¡Movimiento registrado exitosamente!';
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Caja</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>

<?php
   // Verificar si hay caja abierta
   $check_caja_abierta = $conn->prepare("SELECT * FROM `caja` WHERE admin_id = ? AND estado = 'abierta'");
   $check_caja_abierta->execute([$admin_id]);
   $caja_abierta = $check_caja_abierta->fetch(PDO::FETCH_ASSOC);
?>

<?php if(!$caja_abierta){ ?>
<section class="add-products">
   <h1 class="heading">Abrir Caja</h1>

   <form action="" method="post">
      <div class="flex">
         <div class="inputBox">
            <span>Monto Inicial (requerido)</span>
            <input type="number" class="box" required min="0" step="0.01" placeholder="Ingresa el monto inicial" name="monto_inicial">
         </div>
      </div>
      
      <input type="submit" value="Abrir Caja" class="btn" name="abrir_caja">
   </form>
</section>
<?php }else{ ?>

<section class="dashboard">
   <h1 class="heading">Caja Abierta</h1>

   <div class="box-container">
      <div class="box">
         <h3>Información de Caja</h3>
         <p><strong>Fecha de Apertura:</strong> <?= date('d/m/Y H:i', strtotime($caja_abierta['fecha_apertura'])); ?></p>
         <p><strong>Monto Inicial:</strong> $<?= number_format($caja_abierta['monto_inicial'], 2); ?></p>
         <?php
            // Calcular totales actuales
            $select_ventas_actual = $conn->prepare("SELECT SUM(total_price) as total_ventas, 
                                                            SUM(CASE WHEN method = 'efectivo' THEN total_price ELSE 0 END) as total_efectivo,
                                                            SUM(CASE WHEN method = 'tarjeta' THEN total_price ELSE 0 END) as total_tarjeta
                                                     FROM `orders` WHERE caja_id = ?");
            $select_ventas_actual->execute([$caja_abierta['id']]);
            $ventas_actual = $select_ventas_actual->fetch(PDO::FETCH_ASSOC);
            
            $total_ventas_actual = $ventas_actual['total_ventas'] ?? 0;
            $total_efectivo_actual = $ventas_actual['total_efectivo'] ?? 0;
            $total_tarjeta_actual = $ventas_actual['total_tarjeta'] ?? 0;
         ?>
         <p><strong>Total Ventas:</strong> $<?= number_format($total_ventas_actual, 2); ?></p>
         <p><strong>Total Efectivo:</strong> $<?= number_format($total_efectivo_actual, 2); ?></p>
         <p><strong>Total Tarjeta:</strong> $<?= number_format($total_tarjeta_actual, 2); ?></p>
         <p><strong>Efectivo en Caja:</strong> $<?= number_format($caja_abierta['monto_inicial'] + $total_efectivo_actual, 2); ?></p>
      </div>
   </div>
</section>

<section class="add-products">
   <h1 class="heading">Registrar Movimiento</h1>

   <form action="" method="post">
      <input type="hidden" name="caja_id" value="<?= $caja_abierta['id']; ?>">
      <div class="flex">
         <div class="inputBox">
            <span>Tipo (requerido)</span>
            <select name="tipo" class="box" required>
               <option value="ingreso">Ingreso</option>
               <option value="egreso">Egreso</option>
            </select>
         </div>
         <div class="inputBox">
            <span>Concepto (requerido)</span>
            <input type="text" class="box" required maxlength="200" placeholder="Ingresa el concepto" name="concepto">
         </div>
         <div class="inputBox">
            <span>Monto (requerido)</span>
            <input type="number" class="box" required min="0" step="0.01" placeholder="Ingresa el monto" name="monto">
         </div>
         <div class="inputBox">
            <span>Referencia</span>
            <input type="text" class="box" maxlength="100" placeholder="Número de documento, etc." name="referencia">
         </div>
      </div>
      
      <input type="submit" value="Registrar Movimiento" class="btn" name="add_movimiento">
   </form>
</section>

<section class="show-products">
   <h1 class="heading">Movimientos de Caja</h1>

   <div class="box-container">
   <?php
      $select_movimientos = $conn->prepare("SELECT * FROM `movimientos_caja` WHERE caja_id = ? ORDER BY fecha DESC");
      $select_movimientos->execute([$caja_abierta['id']]);
      if($select_movimientos->rowCount() > 0){
         while($movimiento = $select_movimientos->fetch(PDO::FETCH_ASSOC)){ 
   ?>
   <div class="box">
      <div class="name"><?= $movimiento['concepto']; ?></div>
      <div class="price" style="color: <?= $movimiento['tipo'] == 'ingreso' ? 'green' : 'red'; ?>">
         <?= $movimiento['tipo'] == 'ingreso' ? '+' : '-'; ?>$<?= number_format($movimiento['monto'], 2); ?>
      </div>
      <div class="details">
         <p><strong>Tipo:</strong> <?= ucfirst($movimiento['tipo']); ?></p>
         <p><strong>Fecha:</strong> <?= date('d/m/Y H:i', strtotime($movimiento['fecha'])); ?></p>
         <?php if($movimiento['referencia']){ ?>
         <p><strong>Referencia:</strong> <?= $movimiento['referencia']; ?></p>
         <?php } ?>
      </div>
   </div>
   <?php
         }
      }else{
         echo '<p class="empty">¡No hay movimientos registrados!</p>';
      }
   ?>
   </div>
</section>

<section class="add-products">
   <h1 class="heading">Cerrar Caja</h1>

   <form action="" method="post">
      <input type="hidden" name="caja_id" value="<?= $caja_abierta['id']; ?>">
      <div class="flex">
         <div class="inputBox">
            <span>Monto Final en Caja (requerido)</span>
            <input type="number" class="box" required min="0" step="0.01" placeholder="Ingresa el monto final contado" name="monto_final">
         </div>
         <div class="inputBox">
            <span>Observaciones</span>
            <textarea name="observaciones" placeholder="Observaciones del cierre" class="box" maxlength="500" cols="30" rows="5"></textarea>
         </div>
      </div>
      
      <input type="submit" value="Cerrar Caja" class="btn" name="cerrar_caja" onclick="return confirm('¿Estás seguro de cerrar la caja?');">
   </form>
</section>

<?php } ?>

<section class="show-products">
   <h1 class="heading">Historial de Cajas</h1>

   <div class="box-container">
   <?php
      $select_cajas = $conn->prepare("SELECT * FROM `caja` WHERE admin_id = ? ORDER BY fecha_apertura DESC LIMIT 10");
      $select_cajas->execute([$admin_id]);
      if($select_cajas->rowCount() > 0){
         while($caja = $select_cajas->fetch(PDO::FETCH_ASSOC)){ 
   ?>
   <div class="box">
      <div class="name">Caja del <?= date('d/m/Y', strtotime($caja['fecha_apertura'])); ?></div>
      <div class="details">
         <p><strong>Estado:</strong> <span style="color: <?= $caja['estado'] == 'abierta' ? 'green' : 'gray'; ?>"><?= ucfirst($caja['estado']); ?></span></p>
         <p><strong>Apertura:</strong> <?= date('d/m/Y H:i', strtotime($caja['fecha_apertura'])); ?></p>
         <?php if($caja['fecha_cierre']){ ?>
         <p><strong>Cierre:</strong> <?= date('d/m/Y H:i', strtotime($caja['fecha_cierre'])); ?></p>
         <?php } ?>
         <p><strong>Monto Inicial:</strong> $<?= number_format($caja['monto_inicial'], 2); ?></p>
         <?php if($caja['estado'] == 'cerrada'){ ?>
         <p><strong>Monto Final:</strong> $<?= number_format($caja['monto_final'], 2); ?></p>
         <p><strong>Total Ventas:</strong> $<?= number_format($caja['total_ventas'], 2); ?></p>
         <p><strong>Diferencia:</strong> <span style="color: <?= $caja['diferencia'] == 0 ? 'green' : 'red'; ?>">$<?= number_format($caja['diferencia'], 2); ?></span></p>
         <?php } ?>
      </div>
      <?php if($caja['estado'] == 'cerrada'){ ?>
      <div class="flex-btn">
         <a href="ver_caja.php?id=<?= $caja['id']; ?>" class="option-btn">Ver Detalle</a>
      </div>
      <?php } ?>
   </div>
   <?php
         }
      }else{
         echo '<p class="empty">¡No hay historial de cajas!</p>';
      }
   ?>
   </div>
</section>

<script src="../js/admin_script.js"></script>
   
</body>
</html>
